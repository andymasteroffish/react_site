/*
 *  AccelBall.h
 *  reciever2
 *
 *  Created by Andrew Wallace on 4/28/11.
 *  Copyright 2011 Cool Town Inc. All rights reserved.
 *
 */

#include "ofMain.h"

#pragma once

class AccelBall{

public:
	
	void setup(int _id);
	void update(int _val0, int _val1, int _val2);
	void draw();
	void setSound();
	void resetMinMax();	//erases old min and max values
	
	int ballID;
	int val0;
	int val1;
	int val2;
	int speed;
		
	//keep track of the max and min values read to use
	int maxVal;
	int minVal;
	
	//log the data
	#define DATANUM 256
	int curLoc;		//current loaction in the array bieng written
	int xVals[DATANUM];
	int yVals[DATANUM];
	int zVals[DATANUM];
	
	//checking for spinning
	int timeSinceXChange;
	int timeSinceYChange;
	int timeSinceZChange;
	int spinTimer;		//how long since a spin, used to switch modes

	
	int speeds[DATANUM];
	
	//sounds
	int freq;
	int fDist;		//NOT BEING USED
	int blip;		//NOT BEING USED
	int distort;
	int detune;
	int amp;
	
	int muteTimer;	//how long the ball has been below the movement levelr equired to make sound
	bool mute;
	
	//color
	int col1;
	int col2;
	int col3;
	
	//testing
	int timeSinceChange;
};