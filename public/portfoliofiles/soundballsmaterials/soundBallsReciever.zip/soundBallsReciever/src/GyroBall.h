/*
 *  gyroBall.h
 *  reciever2
 *
 *  Created by Andrew Wallace on 4/27/11.
 *  Copyright 2011 Cool Town Inc. All rights reserved.
 *
 */


#include "ofMain.h"
#pragma once

class GyroBall{
	
public:
	
	void setup(int _id);
	void update(int _val0, int _val1);
	void draw();
	void setAllData();	//sets the whole data array to be the current value
	void setRestVal();	//sets the the rest Value to be the current reading 
	bool checkForCollision();
	bool checkForCollisionMedianFilter();
	
	void setSound();
	
	//raw data coming in
	int ballID;
	int val0;
	int val1;
	
	bool hit;	//flag telling if the ball has collided
	
	//processed data
	int speed;
	
#define DATANUM 256
	int curLoc;		//current loaction in the array bieng written
	int xVals[DATANUM];
	int yVals[DATANUM];
	int speeds[DATANUM];
	int distance[DATANUM];
	
	//make sure enough time passed in between collisions
	int collisionTimer;
	
	//try to find the speed to the ball when it is not moving
	int restVal0;
	int restVal1;
	
	//sound
	int freq;
	int amp;
	
	bool mute;
	
	//testing
	int timeSinceChange;
	
	//color
	int col1;
	int col2;
	int col3;
	
};