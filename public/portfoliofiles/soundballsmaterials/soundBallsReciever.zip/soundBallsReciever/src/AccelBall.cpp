/*
 *  AccelBall.cpp
 *  reciever2
 *
 *  Created by Andrew Wallace on 4/28/11.
 *  Copyright 2011 Cool Town Inc. All rights reserved.
 *
 */

#include "AccelBall.h"


void AccelBall::setup(int _id){
	ballID=_id;
	
	//start the other values ff being blank
	val0=400;
	val1=401;	
	val2=402;
	
	//intialize all data to 0
	for (int i=0; i<DATANUM; i++){
		xVals[i]=0;
		yVals[i]=0;
		zVals[i]=0;
		speeds[i]=0;
	}
	curLoc=0;
	
	//start the min and max off in crazy places so they'll get reset
	resetMinMax();
	
	muteTimer=0;
	
	mute=false;
	
	//set the sound
	setSound();
	
	timeSinceXChange=0;
	timeSinceYChange=0;
	timeSinceZChange=0;
	spinTimer=100;
	
	timeSinceChange=0;
	
	amp=0;
	
	//set colors
	if (ballID==2){
		col1=0x1060E0;
		col2=0x255CB3;
		col3=0x31B2CC;
	}
	else if (ballID==3){	//controll ball
		col1=0xD1D900;
		col2=0xFF2B2F;
		col3=0x60AD24;
	}
	
}
void AccelBall::update(int _val0, int _val1, int _val2){
	//advance the muteTimer and the spin timer
	muteTimer++;
	spinTimer++;
	
	//advance the possition of the data
	if(++curLoc==DATANUM)
		curLoc=0;
	
	//make sure the new values are not huge spikes
	int threshold=100;
	if(abs(_val0-val0)<threshold)
		val0=_val0;
	if(abs(_val1-val1)<threshold)
		val1=_val1;
	if(abs(_val2-val2)<threshold)
		val2=_val2;
	
	//store the data in the arrays
	xVals[curLoc]=val0;
	yVals[curLoc]=val1;
	zVals[curLoc]=val2;
	
	//check if the individual values changed from the last check
	if (xVals[curLoc]==xVals[(curLoc-1+DATANUM)%DATANUM])  timeSinceXChange++;
	else  timeSinceXChange=0;
	
	if (yVals[curLoc]==yVals[(curLoc-1+DATANUM)%DATANUM])  timeSinceYChange++;
	else  timeSinceYChange=0;
	
	if (zVals[curLoc]==zVals[(curLoc-1+DATANUM)%DATANUM])  timeSinceZChange++;
	else  timeSinceZChange=0;
	
	//check for spinning
	//make sure at least two axes have not changed in a while
	int minTime=5;
	if ( ((timeSinceXChange>minTime && timeSinceYChange>minTime) ||
		 (timeSinceYChange>minTime && timeSinceZChange>minTime)  ||
		 (timeSinceXChange>minTime && timeSinceZChange>minTime)) && 
		!(timeSinceXChange>minTime && timeSinceYChange>minTime && timeSinceZChange>minTime) &&
		 speeds[(curLoc-minTime-3+DATANUM)%DATANUM]>5){
			cout<<"SPINNNNNNN "<<ballID<<endl;
			spinTimer=0;	//reset the spin timer
	}
	
	//see if the values changed at all
	if (xVals[curLoc]==xVals[(curLoc-1+DATANUM)%DATANUM]
		&& yVals[curLoc]==yVals[(curLoc-1+DATANUM)%DATANUM]
		&& zVals[curLoc]==zVals[(curLoc-1+DATANUM)%DATANUM])
		timeSinceChange++;
	else 
		timeSinceChange=0;
	
	
	//set the speed as the largest distance between readings
	speed=max(abs(xVals[curLoc]-xVals[(curLoc-1+DATANUM)%DATANUM]),
			  abs(yVals[curLoc]-yVals[(curLoc-1+DATANUM)%DATANUM]));
	speed=max(speed,abs(zVals[curLoc]-zVals[(curLoc-1+DATANUM)%DATANUM]));
	
	speeds[curLoc]=speed;
	
	//if the speed is above a certain threshold, reset the mute timer
	if (speed>12)
		muteTimer=0;
	
	//check if any of the reading are the highest or lowest
	if (xVals[curLoc]>maxVal) maxVal=xVals[curLoc];
	if (yVals[curLoc]>maxVal) maxVal=yVals[curLoc];
	if (zVals[curLoc]>maxVal) maxVal=zVals[curLoc];
	
	if (xVals[curLoc]<minVal) minVal=xVals[curLoc];
	if (yVals[curLoc]<minVal) minVal=yVals[curLoc];
	if (zVals[curLoc]<minVal) minVal=zVals[curLoc];
	
	//set the sound
	setSound();
}

void AccelBall::draw(){
	for (int i=0; i<DATANUM-1; i++){
		ofSetColor(col1);
		ofLine(i*4, xVals[i], i*4+4, xVals[i+1]);
		
		ofSetColor(col2);
		ofLine(i*4, yVals[i], i*4+4, yVals[i+1]);
		
		ofSetColor(col3);
		ofLine(i*4, zVals[i], i*4+4, zVals[i+1]);
		
		ofSetColor(col1);
		ofLine(i*4, speeds[i], i*4+4, speeds[i+1]);
	}
	
	
	//text read out
	int textX=400;
	textX=200 + ballID*150;
	int textY=30;
	int spacing=20;
	int s=0;
	ofSetColor(col1);
	if (ballID==3)
		ofDrawBitmapString("Control Ball", textX, textY+spacing*s++);
	else 
		ofDrawBitmapString("Accel Ball", textX, textY+spacing*s++);

	ofSetColor(0,0, 0);
	ofDrawBitmapString("id    : "+ofToString(ballID), textX, textY+spacing*s++);
	ofDrawBitmapString("val0  : "+ofToString(val0), textX, textY+spacing*s++);
	ofDrawBitmapString("val1  : "+ofToString(val1), textX, textY+spacing*s++);
	ofDrawBitmapString("val2  : "+ofToString(val2), textX, textY+spacing*s++);
	ofDrawBitmapString("min   : "+ofToString(minVal), textX, textY+spacing*s++);
	ofDrawBitmapString("max   : "+ofToString(maxVal), textX, textY+spacing*s++);
	ofDrawBitmapString("speed : "+ofToString(speed), textX, textY+spacing*s++);
	ofDrawBitmapString("timer : "+ofToString(muteTimer), textX, textY+spacing*s++);
	ofDrawBitmapString("freq  : "+ofToString(freq), textX, textY+spacing*s++);
	ofDrawBitmapString("fDist : "+ofToString(fDist), textX, textY+spacing*s++);
	ofDrawBitmapString("detune: "+ofToString(detune), textX, textY+spacing*s++);
	ofDrawBitmapString("distor: "+ofToString(distort), textX, textY+spacing*s++);
	ofDrawBitmapString("amp   : "+ofToString(amp), textX, textY+spacing*s++);
	ofDrawBitmapString("mute  : "+ofToString(mute), textX, textY+spacing*s++);
	ofDrawBitmapString("spin  : "+ofToString(spinTimer), textX, textY+spacing*s++);
	ofDrawBitmapString("noChng: "+ofToString(timeSinceChange), textX, textY+spacing*s++);
}

void AccelBall::setSound(){
	freq=ofMap(val0,minVal,maxVal,300,1500, true);
	fDist=ofMap(val2,minVal,maxVal,-50,400, true);
	distort=ofMap(val1,minVal,maxVal,400,1500,true);
	detune=ofMap(val2,minVal,maxVal,1,600, true);
	
	amp=ofMap(muteTimer,0,10,300,0,true)*0.7;
	
	if (mute)
		amp=0;
	
}

void AccelBall::resetMinMax(){
	//start the min and max off in crazy places so they'll get reset
	minVal=100000;
	maxVal=1;
}
