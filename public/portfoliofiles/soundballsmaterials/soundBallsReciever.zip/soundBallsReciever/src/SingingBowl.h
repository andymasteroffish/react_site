/*
 *  Ball.h
 *  gyroCollisionSound
 *
 *  Created by Andrew Wallace on 4/20/11.
 *  Copyright 2011 Cool Town Inc. All rights reserved.
 *
 */

#include "ofMain.h"
#pragma once

class SingingBowl{

	public:
	
	void setup(int _id);
	void update(int _val0, int _val1, int _val2);	//accelerometer ball update
	void update(int _val0, int _val1);				//gyro ball update
	void draw();
	void setAllData();	//sets the whole data array to be the current value
	void setRestVal();	//sets the the rest Value t be the current reading 
	void setSound();
	void startRecording();
	void endSound();
	void clearSound();
	
	bool gyro;	//is this using a gyro or accelerometer ball
	
	//raw data coming in
	int ballID;
	//this test uses val - val3 as the acelerometer values
	int val0;
	int val1;
	int val2;
	
	//keep track of the max and min values read to use
	int maxVal;
	int minVal;
	
	//processed data
	int speed;
	
	#define DATANUM 256
	int curLoc;		//current loaction in the array bieng written
	int xVals[DATANUM];
	int yVals[DATANUM];
	int zVals[DATANUM];
	
	int speeds[DATANUM];
	
	//checking for spinning
	int timeSinceXChange;
	int timeSinceYChange;
	int timeSinceZChange;
	int spinTimer;		//how long since a spin, used to switch modes
	
	int stillTimer;
	int minCount;	//lowest count value that will still be used
	
	
	// info for gyro ball
	//try to find the speed to the ball when it is not moving
	int restVal0;
	int restVal1;
	
	
	//make sounds
	int synthId;
	bool mute;
	
	bool end;
	int endAmp;
	int endTime;
	
	int count;
	
	bool singing;
	
	//values
	int freq;
	int amp;
	int detune;
	
	//play back info
	bool playback;
	int playbackTime;
	int playbackLength;
	int pauseTime;	//how long to wait silently before starting the next playback
	
	//color
	int col1;
	int col2;
	int col3;
	
	//testing
	int timeSinceChange;

};