#include "testApp.h"

//--------------------------------------------------------------
void testApp::setup(){	
	ofSetFrameRate(150);
	// open an outgoing connection to HOST:PORT
	sender.setup( HOST, PORT );
	synthId = 100;	//needs to start above 2
	
	//load the XML file if we're playing from a recording
	#ifdef USE_REC
		XML.loadFile("longRollHitBad.xml");	//change the name here to select which xml file to use
	#endif
	
	//set up controll Pannel
	panel.setup("control", 770, 0, 300, 400);
	panel.addPanel("volume", 1, false);
	
	panel.setWhichPanel("volume");
	
	panel.addSlider("Gyro Whine Vol", "GVOL", 1,0.01,4, false);
	panel.addSlider("Gyro Chime Vol", "CVOL", 1,0.01,4, false);
	panel.addSlider("Accel Vol", "ACCELVOL", 1,0.01,4, false);
	panel.addSlider("Alt Gyro Vol", "GVOLALT", 1,0.01,4, false);
	panel.addSlider("Sining Bowl Vol", "SINGVOL", 1,0.01,4, false);
	panel.addSlider("Sining Bowl Burst", "SINGBURSTVOL", 1,0.01,4, false);
	
	panel.loadSettings("settings.xml");
	
	
	//is singingbowl on?
	singingBowlsActive=false;
	lastSwitch=0;

	ofSetVerticalSync(true);

	bSendSerialMessage = false;
	ofBackground(230,230,230);	
	
	
	serial.enumerateDevices();
			
	
	//----------------------------------- note:
	// < this should be set
	// to whatever com port
	// your serial device is
	// connected to.
	// (ie, COM4 on a pc, /dev/tty.... on linux, /dev/tty... on a mac)
	// arduino users check in arduino app....

	//serial.setup("COM4");  						  // windows example
	serial.setup("/dev/tty.usbserial-A700fjwn",9600); // mac osx example
	//serial.setup("/dev/ttyUSB0", 9600);			  //linux example

	//----------------------------------- 
	nTimesRead = 0;
	nBytesRead = 0;
	readTime = 0;
	memset(bytesReadString, 0, 4);
	
	//set up the balls
	//GYRO
	for (int i=0; i<3; i++){
		gyro[i].setup(i);
		//create a new synth for each gyro
		ofxOscMessage m;
		m.setAddress( "/s_new");
		m.addStringArg("gyro");
		m.addIntArg(GYROSTART+i);
		m.addIntArg(1);
		m.addIntArg(0);
		sender.sendMessage( m );
	}
	
	//create the alt gyro synth
	ofxOscMessage a;
	a.setAddress( "/s_new");
	a.addStringArg("altGyro");
	a.addIntArg(ALTGYROSTART);
	a.addIntArg(1);
	a.addIntArg(0);
	sender.sendMessage( a );
	
	//ACCELEROMETER BALL
	accelBall[0].setup(2);
	accelBall[1].setup(3);
	//only need one synth because one of the accel balls is silent
	ofxOscMessage m;
	m.setAddress( "/s_new");
	m.addStringArg("accelBall2");
	m.addIntArg(ACCELSTART);
	m.addIntArg(1);
	m.addIntArg(0);
	sender.sendMessage( m );


	//create a singing bowl for each ball
	for (int i=0; i<BALLNUM; i++){
		singingBowl[i].setup(i);
		//set up the synths
		ofxOscMessage m;
		m.setAddress( "/s_new");
		m.addStringArg("singBowl");
		m.addIntArg(SINGINGBOWLSTART+i);
		m.addIntArg(1);
		m.addIntArg(0);
		sender.sendMessage( m );
	}
	
	
	//start the counter
	counter=0;
	
	checkNext=0;
	
	mute=false;
	pause=false;
	
	recordingXML=false;
	xmlPos=0;	//start the position at 0
	
}

//--------------------------------------------------------------
void testApp::update(){
	//read the value form the pannel
	panel.update();
	gyroVol=panel.getValueF("GVOL");
	chimeVol=panel.getValueF("CVOL");
	accellVol=panel.getValueF("ACCELVOL");
	gVolAlt=panel.getValueF("GVOLALT");
	singVol=panel.getValueF("SINGVOL");
	singBurstVol=panel.getValueF("SINGBURSTVOL");
	
	//increase timer and request info if it's time
	#ifdef USE_REC
		if (++counter==10 && !pause){
			counter=0;
			updateFromRecording();
		}
	#else
		if (++counter==2){
			counter=0;	//reset counter
			bSendSerialMessage=true;
		}
	#endif
	
	
	if (bSendSerialMessage){
		
		// send a signal to serial to arduino base station info
		if (checkNext==0)
			serial.writeByte('0');
		else if (checkNext==1)
			serial.writeByte('1');
		else if (checkNext==2)
			serial.writeByte('2');
		else if (checkNext==3)
			serial.writeByte('3');
		else if (checkNext==4)
			serial.writeByte('4');
		
		//read in the data it sends back
		nTimesRead = 0;
		nBytesRead = 0;
		int nRead  = 0;  // a temp variable to keep count per read
		
		unsigned char bytesReturned[MESSAGESIZE];
		memset(bytesReadString, 0, MESSAGESIZE+1);
		memset(bytesReturned, 0, MESSAGESIZE);
		
		//get whatever is in Serial
		nRead = serial.readBytes( bytesReturned, MESSAGESIZE);
		nTimesRead++;
		nBytesRead = nRead;
		
		memcpy(bytesReadString, bytesReturned, MESSAGESIZE);
		
		bSendSerialMessage = false;	//note that we sent the message
		readTime = ofGetElapsedTimef();	//note the time of the read
		
		//create an unsigned char for each byte of incoming data
		unsigned char idBottom;
		unsigned char val0Top;
		unsigned char val0Bottom;
		unsigned char val1Top;
		unsigned char val1Bottom;
		unsigned char val2Top;
		unsigned char val2Bottom;
		
		//go through and get the info for each ball

		//assign each byte
		idBottom=bytesReturned[0];
		val0Top=bytesReturned[1];
		val0Bottom=bytesReturned[2];
		val1Top=bytesReturned[3];
		val1Bottom=bytesReturned[4];
		val2Top=bytesReturned[5];
		val2Bottom=bytesReturned[6];
		
		//put the bytes back together as ints
		//IN THIS TEST I AM USING val AND val2 AS THE TWO GYRO VALUES
		int ballID= idBottom;
		int val0=val0Top<<8 | val0Bottom;
		int val1=val1Top<<8 | val1Bottom;
		int val2=val2Top<<8 | val2Bottom;
		
		//cout<<ballID<<": "<<val2<<endl;
		
		//set the ballID based on the one we should b checking as opposed to the info sent in the data packet
		//for some reason, idBottom equals 0 far more often than it should, which causes ball0 to be updated faster than it changes
		ballID=checkNext-1;
		if (ballID==-1)	ballID=4;

		if (!pause){
			//set the normal values if singing bowls are not active
			if (!singingBowlsActive){
				//gyro
				if (ballID==0 || ballID==1){
					gyro[ballID].update(val0,val1);
					gyroSound(ballID);
				}
				//alt gyro ball
				else if (ballID==4){
					gyro[2].update(val0, val1);
					altGyroSound(2);
				}
				//accelerometer ball
				else if (ballID==2){
					accelBall[0].update(val0, val1, val2);
					accelSound();
				}
				//control Ball
				else if (ballID==3){
					accelBall[1].update(val0, val1, val2);
				}
			}else{
				//otherwise set all of the singing bowls
				if (ballID==0 || ballID==1 || ballID==4)
					singingBowl[ballID].update(val0, val1);
				//and the accelerometer balls
				if (ballID==2 || ballID==3) 
					singingBowl[ballID].update(val0,val1,val2);
				//and make the sounds
				singingBowlSound(ballID);
			}
		}
		
		//clear out whatever is left over in the Serial
		serial.flush(true, true);
		
		//if both accel balls are spinning switch modes
		int spinTime=30;	//the two spins must occur within this time
		if ( (accelBall[0].spinTimer<spinTime && accelBall[1].spinTimer<spinTime) ||
			 (singingBowl[2].spinTimer<spinTime &&singingBowl[3].spinTimer<spinTime)
			  && ofGetElapsedTimef()-lastSwitch>10)
					switchMode();
		
		//advance and reset check next
		if (++checkNext==BALLNUM){
			checkNext=0;
			//since we've done a full cycle, now is the time to capture if we're recording
			if (recordingXML)	recordXML();
		}
	}
}

//--------------------------------------------------------------
void testApp::draw(){

	//draw the grid
//	ofSetColor(200, 200, 200);
//	for (int i=0; i<DATANUM; i++){
//		ofLine(i*4, 0, i*4, ofGetHeight());
//	}
	
	panel.draw();

	//draw the data
	if (singingBowlsActive){
		for (int i=0; i<BALLNUM; i++)
			singingBowl[i].draw();
	}else{
		for (int i=0; i<2; i++)
			accelBall[i].draw();
		for (int i=0; i<3; i++)
			gyro[i].draw();
	}
	
	//other info
	ofDrawBitmapString("mute : "+ofToString(mute), 30, 700);
	ofDrawBitmapString("mouseY: "+ofToString(mouseY), 30, 720);
	ofDrawBitmapString("next: "+ofToString(checkNext), 30, 740);
	ofDrawBitmapString("recording: "+ofToString(recordingXML), 30, 760);
	
}


//--------------------------------------------------------------
void testApp::keyPressed  (int key){ 
	cout<<key<<endl;
	
	//mut or un mute
	if(key==109){	//m
		toggleMute();
	}
	
	//set restValues for the gyroBalls
	if(key==114){
		for (int i=0; i<3; i++)
			gyro[i].setRestVal();
		for (int i=0; i<BALLNUM; i++)
			singingBowl[i].setRestVal();
		for (int i=0; i<2; i++)
			 accelBall[0].resetMinMax();
	}

	//clear sounds on the sound balls
	if (key==99){	//c for clear
		for (int i=0; i<BALLNUM; i++)
			singingBowl[i].clearSound();
	}
	
	//switch modes
	if (key==115){	//s for switch
		switchMode();
	}
	
	if (key==120)	//x
		recordingXML=!recordingXML;
	
	//stop colelcting data
	if (key==112)	//p for pause
		pause=!pause;
}

//--------------------------------------------------------------
void testApp::keyReleased(int key){ 
	
}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){
	
}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){
	panel.mouseDragged(x,y,button);
}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){
	panel.mousePressed(x,y,button);
}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){
	panel.mouseReleased();
}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

void testApp::toggleMute(){
	mute= !mute;
	for (int i=0; i<3; i++)
		gyro[i].mute=mute;
	for (int i=0; i<2; i++)
		accelBall[i].mute=mute;
	for (int i=0; i<BALLNUM; i++)
		singingBowl[i].mute=mute;
}

void testApp::switchMode(){
	//set all of the amps to 0 and update the sound to clear everything
	//update the sounds now that they are muted
	for (int i=0; i<2; i++){
		gyro[i].amp=0;
		gyroSound(i);
	}
	gyro[2].amp=0;
	altGyroSound(2);
	accelBall[0].amp=0;
	accelSound();
	for (int i=0; i<BALLNUM; i++){
		singingBowl[i].amp=0;
		singingBowlSound(i);
	}
	//change the mode over
	singingBowlsActive=!singingBowlsActive;
	
	//reset the spin timers
	for (int i=0; i<2; i++){
		accelBall[i].spinTimer=100;
		singingBowl[i+2].spinTimer=100;	//singing bowls 2 & 3 are accel balls
	}
	
	//reset the time of last switch
	lastSwitch=ofGetElapsedTimef();

}

void testApp::gyroSound(int b){
	
	//frequency based on accelerometer ball
	int freq=gyro[b].freq;
	if (b==0)
		freq=ofMap(accelBall[1].val0, accelBall[1].minVal, accelBall[1].maxVal,780,1568, true);	//roughly between G5 and G6
	if (b==1)
		freq=ofMap(accelBall[1].val1, accelBall[1].minVal, accelBall[1].maxVal,130,262, true);	//roughly between C3 and C4
	
	ofxOscMessage m;
	m.setAddress( "/n_set");
	m.addIntArg(GYROSTART+b);
	m.addStringArg("freq");
	m.addIntArg(freq);
	m.addStringArg("amp");
	m.addIntArg((int)gyro[b].amp*gyroVol);
	sender.sendMessage( m );
	
	//make a collision sound if the hit flag is up
	if (gyro[b].hit){
		gyro[b].hit=false;	//put the flag down
		
		ofxOscMessage m;
		m.setAddress( "/s_new");
		m.addStringArg("gyroHit");
		m.addIntArg(synthId);
		m.addIntArg(1);	/// ? please tell zach what this means. for extra credit!
		m.addIntArg(0); /// :)
		m.addStringArg("freq");
		m.addIntArg(freq);
		m.addStringArg("amp");
		if (!mute)
			m.addIntArg((int)100*chimeVol);
		else
			m.addIntArg(0);
		sender.sendMessage( m );
		synthId++;
	}
}

void testApp::altGyroSound(int b){
	//set the values here based on the ball's values
	int freq=ofMap(accelBall[1].val2, accelBall[1].minVal, accelBall[1].maxVal,164,330, true);	//roughly between E3 and E4
	int saw=ofMap(accelBall[1].val1, accelBall[1].minVal, accelBall[1].maxVal,500,1500, true);	
	
	ofxOscMessage m;
	m.setAddress( "/n_set");
	m.addIntArg(ALTGYROSTART);
	m.addStringArg("freq");
	m.addIntArg(freq);
	m.addStringArg("amp");
	m.addIntArg((int)(gyro[b].amp*gVolAlt)/3);	//dividing by 3 becaus eit creates 3 tones
	m.addStringArg("saw");
	m.addIntArg(saw);
	sender.sendMessage( m );
}


void testApp::accelSound(){
	ofxOscMessage m;
	m.setAddress( "/n_set");
	m.addIntArg(ACCELSTART);
	m.addStringArg("freq");
	m.addIntArg(accelBall[0].freq);
	m.addStringArg("fDist");
	m.addIntArg(accelBall[0].fDist);
	m.addStringArg("distort");
	m.addIntArg(accelBall[0].distort);
	m.addStringArg("detune");
	m.addIntArg(100);
	m.addStringArg("amp");
	m.addIntArg(int(accelBall[0].amp*accellVol));
	sender.sendMessage( m );
}

void testApp::singingBowlSound(int b){	
	//if the end flag isn't up, make the normal sounds
	if (!singingBowl[b].end){
		ofxOscMessage m;
		m.setAddress( "/n_set");
		m.addIntArg(SINGINGBOWLSTART+b);
		m.addStringArg("freq");
		m.addIntArg(singingBowl[b].freq);
		m.addStringArg("amp");
		m.addIntArg(singingBowl[b].amp*singVol);
		m.addStringArg("detune");
		m.addIntArg(singingBowl[b].detune);
		sender.sendMessage( m );
	}else {
		//otherwise, make the end sound and put the flag back down
		ofxOscMessage m;
		m.setAddress( "/s_new");
		m.addStringArg("singBowlEnd");
		m.addIntArg(synthId);
		m.addIntArg(1);	/// ? please tell zach what this means. for extra credit!
		m.addIntArg(0); /// :)
		m.addStringArg("freq");
		m.addIntArg(singingBowl[b].freq);
		m.addStringArg("amp");
		m.addIntArg((int)singingBowl[b].amp*2*singBurstVol);	//make the chime louder
		sender.sendMessage( m );
		synthId++;
		
		singingBowl[b].end=false;	//turn off the flag
	}
}



void testApp::recordXML(){
	//cout<<"record"<<endl;
	//go thorugh each ball 
	for (int i=0; i<3; i++){
		XML.setValue("GYRO"+ofToString(gyro[i].ballID)+":XVALS:X"+ofToString(xmlPos),gyro[i].xVals[gyro[i].curLoc] );
		XML.setValue("GYRO"+ofToString(gyro[i].ballID)+":YVALS:Y"+ofToString(xmlPos),gyro[i].yVals[gyro[i].curLoc] );
	
	}
	for (int i=0; i<2; i++){
		XML.setValue("ACCEL"+ofToString(accelBall[i].ballID)+":XVALS:X"+ofToString(xmlPos),accelBall[i].xVals[accelBall[i].curLoc] );
		XML.setValue("ACCEL"+ofToString(accelBall[i].ballID)+":YVALS:Y"+ofToString(xmlPos),accelBall[i].yVals[accelBall[i].curLoc] );
		XML.setValue("ACCEL"+ofToString(accelBall[i].ballID)+":ZVALS:Z"+ofToString(xmlPos),accelBall[i].zVals[accelBall[i].curLoc] );
	}
	
	XML.saveFile("recording.xml");
	
	//advance the position
	xmlPos++;
}

//update all of the balls based on the recording xml file
void testApp::updateFromRecording(){
	//cout<<xmlPos<<endl;
	for (int i=0; i<3; i++){
		gyro[i].update(XML.getValue("GYRO"+ofToString(gyro[i].ballID)+":XVALS:X"+ofToString(xmlPos),0),
					   XML.getValue("GYRO"+ofToString(gyro[i].ballID)+":YVALS:Y"+ofToString(xmlPos),0));
	}
	for (int i=0; i<2; i++){
		accelBall[i].update(XML.getValue("ACCEL"+ofToString(accelBall[i].ballID)+":XVALS:X"+ofToString(xmlPos),0),
							XML.getValue("ACCEL"+ofToString(accelBall[i].ballID)+":XVALS:Y"+ofToString(xmlPos),0),
							XML.getValue("ACCEL"+ofToString(accelBall[i].ballID)+":XVALS:Z"+ofToString(xmlPos),0));
	}
	
	//advance the position
	xmlPos++;
}
	


