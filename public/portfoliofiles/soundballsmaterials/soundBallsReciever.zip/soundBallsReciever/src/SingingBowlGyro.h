/*
 *  SinginBowlGyro.h
 *  reciever3
 *
 *  Created by Andrew Wallace on 4/30/11.
 *  Copyright 2011 Cool Town Inc. All rights reserved.
 *
 */

//This ball acts like the singingbowl, but is designed to be used with the gyroscope ball

#include "ofMain.h"
#pragma once

/*
 KILL ME
 */

class SingingBowlGyro{
	
public:
	
	void setup();
	void update(int _val0, int _val1);
	void draw();
	void setAllData();	//sets the whole data array to be the current value
	void setRestVal();	//sets the the rest Value t be the current reading 
	void setSound();
	void startRecording();
	void endSound();
	
	
	//raw data coming in
	int ballID;
	//this test uses val - val3 as the acelerometer values
	int val0;
	int val1;
	int val2;

	
	//processed data
	int speed;
	
#define DATANUM 256
	int curLoc;		//current loaction in the array bieng written
	int xVals[DATANUM];
	int yVals[DATANUM];
	int zVals[DATANUM];
	
	int speeds[DATANUM];
	
	
	int stillTimer;
	int minCount;	//lowest count value that will still be used
	
	
	//try to find the speed to the ball when it is not moving
	int restVal0;
	int restVal1;
	
	
	//make sounds
	int synthId;
	bool mute;
	
	bool end;
	int endAmp;
	int endTime;
	
	int count;
	
	//values
	int freq[3];
	int amp[3];
	int detune[3];
	
	//play back info
	bool playback;
	int playbackTime;
	int playbackLength;
	int pauseTime;	//how long to wait silently before starting the next playback
	
	//testing
	int timeSinceChange;
	
};