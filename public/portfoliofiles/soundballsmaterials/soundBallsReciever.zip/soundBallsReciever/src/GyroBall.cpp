/*
 *  gyroBall.cpp
 *  reciever2
 *
 *  Created by Andrew Wallace on 4/27/11.
 *  Copyright 2011 Cool Town Inc. All rights reserved.
 *
 */

#include "GyroBall.h"


void GyroBall::setup(int _id){
	ballID=_id;
	
	//right now, one of the gyros is set to id 4. I'll fix this later
	if (_id==2)
		ballID=4;
	
	//start the other values off being blank
	val0=400;
	val1=400;
	
	hit=false;
	
	speed=0;
	
	//intialize all data to 0
	for (int i=0; i<DATANUM; i++){
		xVals[i]=0;
		yVals[i]=0;
		speeds[i]=0;
		distance[i]=0;
	}
	
	curLoc=0;
	collisionTimer=0;
	
	restVal0=475;
	restVal1=475;
	
	mute=false;
	
	timeSinceChange=0;
	
	//set color based on ballID
	if (ballID==0){
		col1=0xF5C833;
		col2=0xF57E33;
		col3=0xC7801C;
	}
	if (ballID==1){
		col1=0xCC1BE0;
		col2=0xE950FA;
		col3=0xFF0000;
	}
	if (ballID==4){
		col1=0x33F564;
		col2=0x278F41;
		col3=0x37F511;
	}
	
}
void GyroBall::update(int _val0, int _val1){
	//advance the possition of the data
	if(++curLoc==DATANUM)
		curLoc=0;
	
	//set the new values
	if (_val0>50 && _val0<1000)
		val0=_val0;
	if (_val1>50 && _val1<1000)
		val1=_val1;
	
	//store the data in the arrays
	xVals[curLoc]=val0;
	yVals[curLoc]=val1;
	
	//see if the values changed at all
	if (xVals[curLoc]==xVals[(curLoc-1+DATANUM)%DATANUM]
		&& yVals[curLoc]==yVals[(curLoc-1+DATANUM)%DATANUM])
		timeSinceChange++;
	else 
		timeSinceChange=0;
	
	//set the speed
	speeds[curLoc]=max(abs(val0-restVal0),abs(val1-restVal1));
	//smooth out the last few readings to get the speed
	int smoothNum=3;	//how many redings to use
	float total=0;
	for (int i=0; i<smoothNum; i++)
		total+=speeds[(curLoc-i+DATANUM)%DATANUM];
	speed=total/smoothNum;
	
	//set the distance
	distance[curLoc]=abs(xVals[curLoc]-yVals[curLoc]);
	
	//if the speed has been the same for a number of checks, assume this is the new resting speed
	int numCheck=7;	//how far back to check for identical speeds
	bool reset=true;	//assume we should reset the rest val
	for (int i=0; i<numCheck; i++){
		//check if this value is different
		if (speeds[(curLoc-i+DATANUM)%DATANUM]!=speed)
			reset=false;	//if it was diffeent, don't reset rest values
	}
	if (reset) setRestVal();
	
	//check if the ball has been hit
	if(checkForCollision())
		hit=true;
	
	//set the sound
	setSound();
}

void GyroBall::draw(){
	for (int i=0; i<DATANUM-1; i++){
		ofSetColor(col1);
		ofLine(i*4, xVals[i], i*4+4, xVals[i+1]);
		
		ofSetColor(col2);
		ofLine(i*4, yVals[i], i*4+4, yVals[i+1]);
		
		//draw speed vals
		ofSetColor(col1);
		ofLine(i*4, ofGetHeight()-distance[i], i*4+4, ofGetHeight()-distance[i+1]);
		ofSetColor(col3);
		ofLine(i*4, ofGetHeight()-speeds[i], i*4+4, ofGetHeight()-speeds[i+1]);
	}
	
	//text read out
	
	int textX=30 + ballID*150;
	if (ballID==4)	textX=30 + 2*150;
	int textY=30;
	int spacing=20;
	int s=0;
	ofSetColor(col1);
	if (ballID==0 || ballID==1)
		ofDrawBitmapString("Gyro Ball", textX, textY+spacing*s++);
	else
		ofDrawBitmapString("Alt Gyro", textX, textY+spacing*s++);
	ofSetColor(0,0, 0);
	ofDrawBitmapString("id    : "+ofToString(ballID), textX, textY+spacing*s++);
	ofDrawBitmapString("val0  : "+ofToString(val0), textX, textY+spacing*s++);
	ofDrawBitmapString("val1  : "+ofToString(val1), textX, textY+spacing*s++);
	ofDrawBitmapString("speed : "+ofToString(speed), textX, textY+spacing*s++);
	ofDrawBitmapString("hit   : "+ofToString(hit), textX, textY+spacing*s++);
	ofDrawBitmapString("freq  : "+ofToString(freq), textX, textY+spacing*s++);
	ofDrawBitmapString("amp   : "+ofToString(amp), textX, textY+spacing*s++);
	ofDrawBitmapString("noChng: "+ofToString(timeSinceChange), textX, textY+spacing*s++);
}

void GyroBall::setAllData(){
	for (int i=0; i<DATANUM; i++){
		xVals[i]=xVals[(curLoc+DATANUM)%DATANUM];
		yVals[i]=yVals[(curLoc+DATANUM)%DATANUM];
		speeds[i]=speeds[(curLoc+DATANUM)%DATANUM];
		distance[i]=distance[(curLoc+DATANUM)%DATANUM];
	}
}

void GyroBall::setRestVal(){
	restVal0=xVals[(curLoc+DATANUM)%DATANUM];
	restVal1=yVals[(curLoc+DATANUM)%DATANUM];
}


bool GyroBall::checkForCollision(){
	//THIS USES SPEED
	//check if the balls current value in x or y is signifigantly different from its value a few frames ago
	int threshold=60;  //how big the change needs to be to register as an impact	
	
	int collision=false;	//assume the ball did not hit anything
	int arrayDist=2;  //how far back in the array to look for the previous value
	
	int prevSpeed=speeds[(curLoc-arrayDist+DATANUM)%DATANUM];
	
	collisionTimer++;	//increase the timer
	
	if (collisionTimer>2){
		//set the current value and the previous one
		int curVal=speeds[(curLoc+DATANUM)%DATANUM];
		int prevLoc=(curLoc-arrayDist+DATANUM)%DATANUM;	//have it loop around in the array
		int prevVal=speeds[(prevLoc)];
		//check the current value against the previous one
		if (prevVal-curVal>threshold && prevVal>50){
			collisionTimer=0;  //reset timer
			collision=true;
		}
	}
	
	if(collision){
		cout<<"------------------"<<endl;
		cout<<"CRASH - "<<ballID<<endl;
		cout<<speed<<endl;
		cout<<"------------------"<<endl;
		return true;
	}
	return false;
	
	//THIS USES DISTANCE
	//check if the balls current value in x or y is signifigantly different from its value a few frames ago
//	int threshold=50;  //how big the change needs to be to register as an impact	
//	
//	int collision=false;	//assume the ball did not hit anything
//	int arrayDist=2;  //how far back in the array to look for the previous value
//	
//	int prevSpeed=distance[(curLoc-arrayDist+DATANUM)%DATANUM];
//	
//	collisionTimer++;	//increase the timer
//	
//	if (collisionTimer>6){
//		//set the current value and the previous one
//		int curVal=distance[(curLoc+DATANUM)%DATANUM];
//		int prevLoc=(curLoc-arrayDist+DATANUM)%DATANUM;	//have it loop around in the array
//		int prevVal=distance[(prevLoc)];
//		//check the current value against the previous one
//		if (prevVal-curVal>threshold && prevVal>50){
//			collisionTimer=0;  //reset timer
//			collision=true;
//		}
//	}
//	
//	if(collision){
//		cout<<"------------------"<<endl;
//		cout<<"CRASH - "<<ballID<<endl;
//		cout<<speed<<endl;
//		cout<<"------------------"<<endl;
//		return true;
//	}
//	return false;
}

//needs some values being fed to it
void GyroBall::setSound(){
	freq=ofMap(speed,0,200,780,1568);	//roughly between G5 and G6
	amp=ofMap(speed,0,80,1,100,true)*3;
	//if the speed is bellow a certain threshold, keep it silent
	if (speed<5)
		amp=0;
	//kill amp if its muted
	if (mute)
		amp=0;
	

}