/*
 *  SingingBowlGyro.cpp
 *  gyroCollisionSound
 *
 *  Created by Andrew Wallace on 4/20/11.
 *  Copyright 2011 Cool Town Inc. All rights reserved.
 *
 */

#include "SingingBowlGyro.h"


void SingingBowlGyro::setup(){
	ofSetFrameRate(100);
	
	ballID=3;
	
	//start the values with random numbers
	val0=400;
	val1=400;	
	val2=400;
	speed=0;
	
	//intialize all data to 0
	for (int i=0; i<DATANUM; i++){
		xVals[i]=0;
		yVals[i]=0;
		zVals[i]=0;
		speeds[i]=0;
	}
	curLoc=0;
	
	stillTimer=0;
	
	//initialize for values
	for (int i=0; i<3; i++){
		freq[i]=0;
		amp[i]=0;
		detune[i]=0;
	}
	
	playback=true;
	playbackTime=0;
	playbackLength=1;
	pauseTime=100;
	
	minCount=190;
	
	mute=false;
	end=false;
	
	timeSinceChange=0;
	
	restVal0=475;
	restVal1=475;
	
}
void SingingBowlGyro::update(int _val0, int _val1){
	//advance the muteTimer
	stillTimer++;
	
	//set the new values
	if (_val0>50 && _val0<1000)
		val0=_val0;
	if (_val1>50 && _val1<1000)
		val1=_val1;
	
	//store the data in the arrays
	xVals[curLoc]=val0;
	yVals[curLoc]=val1;
	
	//see if the values changed at all
	if (xVals[curLoc]==xVals[(curLoc-1+DATANUM)%DATANUM]
		&& yVals[curLoc]==yVals[(curLoc-1+DATANUM)%DATANUM])
		timeSinceChange++;
	else 
		timeSinceChange=0;
	
	//set the speed
	speeds[curLoc]=max(abs(val0-restVal0),abs(val1-restVal1));
	//smooth out the last few readings to get the speed
	int smoothNum=3;	//how many redings to use
	float total=0;
	for (int i=0; i<smoothNum; i++)
		total+=speeds[(curLoc-i+DATANUM)%DATANUM];
	speed=total/smoothNum;
	
	
	//if the speed is aove a certain threshold, reset the move timer
	//and check to see if this is the start of a movement, turning on recording if it is
	if (speed>20){
		stillTimer=0;
		
		//if it was fast enough to absolutely be deliberate, start recording
		if (speed>50 && playback)
			startRecording();
	}
	
	//if it hasn't moved in 10 checks, say that it stopped, and end the sound if it was being recorded
	if (stillTimer>4 && !playback && !end){
		playbackLength=count;
		//if it was short, assume it was shaken just to reset it
		if (count<minCount)
			playbackLength=1;
		endSound();
	}
	
	//advance the possition of the data
	if(++curLoc==DATANUM)
		curLoc=0;
	
	//set the soudns with the new values
	setSound();
}

void SingingBowlGyro::draw(){
	for (int i=0; i<DATANUM-1; i++){
		ofSetColor(0x33F564);
		ofLine(i*4, xVals[i], i*4+4, xVals[i+1]);
		
		ofSetColor(0x278F41);
		ofLine(i*4, yVals[i], i*4+4, yVals[i+1]);
		
		ofSetColor(0x37F511);
		ofLine(i*4, zVals[i], i*4+4, zVals[i+1]);
		
		ofSetColor(0,255,0);
		ofLine(i*4, speeds[i], i*4+4, speeds[i+1]);
	}
	
	//text read out
	int textX=550;
	int textY=30;
	int spacing=20;
	int s=0;
	ofSetColor(0x33F564);
	ofDrawBitmapString("Singing Bowl G", textX, textY+spacing*s++);
	ofSetColor(0,0, 0);
	ofDrawBitmapString("id    : "+ofToString(ballID), textX, textY+spacing*s++);
	ofDrawBitmapString("val0  : "+ofToString(val0), textX, textY+spacing*s++);
	ofDrawBitmapString("val1  : "+ofToString(val1), textX, textY+spacing*s++);
	ofDrawBitmapString("val2  : "+ofToString(val2), textX, textY+spacing*s++);
	ofDrawBitmapString("speed : "+ofToString(speed), textX, textY+spacing*s++);
	ofDrawBitmapString("count : "+ofToString(count), textX, textY+spacing*s++);
	ofDrawBitmapString("length: "+ofToString(playbackLength), textX, textY+spacing*s++);
	ofDrawBitmapString("still : "+ofToString(stillTimer), textX, textY+spacing*s++);
	ofDrawBitmapString("amp0  : "+ofToString(amp[0]), textX, textY+spacing*s++);
	ofDrawBitmapString("noChng: "+ofToString(timeSinceChange), textX, textY+spacing*s++);
	
}

void SingingBowlGyro::setAllData(){
	for (int i=0; i<DATANUM; i++){
		xVals[i]=xVals[(curLoc-1+DATANUM)%DATANUM];
		yVals[i]=yVals[(curLoc-1+DATANUM)%DATANUM];
		speeds[i]=speeds[(curLoc-1+DATANUM)%DATANUM];
	}
}

void SingingBowlGyro::setRestVal(){
	restVal0=xVals[(curLoc-1+DATANUM)%DATANUM];
	restVal1=yVals[(curLoc-1+DATANUM)%DATANUM];
}


void SingingBowlGyro::setSound(){
	
	count+=10;
	
	int freqs[3]={220,261,659};
	int dist=200;	//how much space in between the tones
	int startAmp=330;
	
	//are we getting new info right now?
	if(!end){
		for (int i=0; i<3; i++){
			freq[i]=freqs[i];
			amp[i]=(int)max(0, (startAmp+count-dist*i)/5);
			if (count<11)
				amp[i]=0;
			detune[i]=count-dist*i;
			
			if(mute)
				amp[i]=0;
		}
		
		//check to see if it is time to end if this is a playback
		if (playback && count>=playbackLength){
			endSound();
		}
	}
}

void SingingBowlGyro::startRecording(){
	playback=false;
	count=0;
	end=false;
	
	//this might be where to set values for the frequencies based on the other balls
}

void SingingBowlGyro::endSound(){
	if (count>minCount){
		end=true;
	}
	endTime=count;
	endAmp=count/10;
	
	playback=true;
	count= -pauseTime;
}
