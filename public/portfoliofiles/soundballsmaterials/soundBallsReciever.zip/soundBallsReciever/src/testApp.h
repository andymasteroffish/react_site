/* Sound Balls
 * Andy Wallace
 * 2011
 *
 * This program recieves messages form an Arduino Base Station 
 * contianing information about the balls
 * OSC messages are sent to SuperCollider to make the sounds
 */


#ifndef _TEST_APP
#define _TEST_APP


#include "ofMain.h"
#include "ofxControlPanel.h"
#include "SingingBowl.h"
#include "gyroBall.h"
#include "AccelBall.h"

#define OF_ADDON_USING_OFXOSC

#define OF_ADDON_USING_OFXXMLSETTINGS
#include "ofAddons.h"

#define HOST "localhost"
#define PORT 12000

//#define USE_REC		//comment this out to use the live values from the balls

class testApp : public ofBaseApp{
	
	public:
		
		void setup();
		void update();
		void draw();
		
		void keyPressed(int key);
		void keyReleased(int key);
		
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void windowResized(int w, int h);
	
	void toggleMute();
	void switchMode();	//toggles between singing bowl mode and normal
	
	void gyroSound(int b);
	void altGyroSound(int b);
	void singingBowlSound(int b);
	void accelSound();
	void recordXML();
	void updateFromRecording();
	
	ofxControlPanel  panel;
	
	//volume adjustments set by controll pannel
	float gyroVol;
	float chimeVol;
	float accellVol;
	float gVolAlt;
	float singVol;
	float singBurstVol;
	
	//make sounds
	int synthId;
	
		#define MESSAGESIZE 7
		bool		bSendSerialMessage;			// a flag for sending serial
		char		bytesRead[MESSAGESIZE];				// data from serial, we will be trying to read 3
		char		bytesReadString[MESSAGESIZE];			// a string needs a null terminator, so we need 3 + 1 bytes
		int			nBytesRead;					// how much did we read?
		int			nTimesRead;					// how many times did we read?
		float		readTime;					// when did we last read?				
		
		ofSerial	serial;
	
	
	#define BALLNUM 5
	//two gyro balls
	GyroBall gyro[3];			//id 0,1 & 4 (should be changed to 0,1,2)
	AccelBall accelBall[2];		//id 2 & 3
	SingingBowl singingBowl[BALLNUM];
	
	bool singingBowlsActive;	//toggles the balls acting as snging bowls
	float lastSwitch;	//time of the last switch in seconds
	
	int counter;	//counts time between asking for info from the balls
	int checkNext;	//which ball to check next
	
	//testing
	int ballSpeed;
	
	bool mute;
	bool pause;	//stop recording data
	
	//balls sounds
	#define SINGINGBOWLSTART 2 
	#define GYROSTART 20 
	#define ALTGYROSTART 25
	#define ACCELSTART 30

	bool recordingXML;
	int xmlPos;
	ofxXmlSettings XML;
private:
	
	ofxOscSender sender;
};

#endif	

