/*
 *  Ball.cpp
 *  gyroCollisionSound
 *
 *  Created by Andrew Wallace on 4/20/11.
 *  Copyright 2011 Cool Town Inc. All rights reserved.
 *
 */

#include "SingingBowl.h"


void SingingBowl::setup(int _id){
	ofSetFrameRate(100);
	
	ballID=_id;
	
	//start the values with random numbers
	val0=400;
	val1=400;	
	val2=400;
	speed=0;

	
	//set the colors
	if (ballID==0){
		col1=0xF5C833;
		col2=0xF57E33;
		col3=0xF5C833;
	}
	else if (ballID==1){
		col1=0xCC1BE0;
		col2=0xE950FA;
		col3=0xCC1BE0;
	}
	else if (ballID==2){
		col1=0x1060E0;
		col2=0x255CB3;
		col3=0x31B2CC;
	}
	else if (ballID==3){
		col1=0x33F564;
		col2=0x278F41;
		col3=0x37F511;
	}
	else if (ballID==4){
		col1=0xB5CF34;
		col2=0x829C02;
	}
	
	//intialize all data to 0
	for (int i=0; i<DATANUM; i++){
		xVals[i]=0;
		yVals[i]=0;
		zVals[i]=0;
		speeds[i]=0;
	}
	curLoc=0;
	
	
	restVal0=475;
	restVal1=475;
	
	//start the min and max off in crazy places so they'll get reset
	minVal=100000;
	maxVal=0;
	
	stillTimer=0;
	
	//spinning
	timeSinceXChange=0;
	timeSinceYChange=0;
	timeSinceZChange=0;
	spinTimer=100;
	
	mute=false;
	end=false;
	singing=false;
	
	timeSinceChange=0;
	
	//set the frequencies
	//using C3, E3, G3, B3, and C4 if they are just one tone for each ball
	if (ballID==0)	freq=130;
	else if (ballID==1)	freq=165;
	else if (ballID==2)	freq=196;
	else if (ballID==3)	freq=261;
	else if (ballID==4)	freq=247;
	
	
	//or randomize it
//	float oneStep=1.05946309;
//	int startFreq=ofRandom(100,200);
//	if (ballID==0)	freq=startFreq;
//	else if (ballID==1)	freq=startFreq*pow(oneStep, 4);
//	else if (ballID==2)	freq=startFreq*pow(oneStep, 7);
//	else if (ballID==3)	freq=startFreq*pow(oneStep, 11);
//	else if (ballID==4)	freq=startFreq*2;
	
	
}

//update for accelerometer ball
void SingingBowl::update(int _val0, int _val1, int _val2){
	//advance the possition of the data
	if(++curLoc==DATANUM)
		curLoc=0;
	
	gyro=false;
	//advance the muteTimer
	stillTimer++;
	
	//make sure the new values are not huge spikes
	int threshold=100;
	if(abs(_val0-val0)<threshold)
		val0=_val0;
	if(abs(_val1-val1)<threshold)
		val1=_val1;
	if(abs(_val2-val2)<threshold)
		val2=_val2;
	
	
	//store the data in the arrays
	xVals[curLoc]=val0;
	yVals[curLoc]=val1;
	zVals[curLoc]=val2;
	
	//see if the values changed at all
	if (xVals[curLoc]==xVals[(curLoc-1+DATANUM)%DATANUM]
		&& yVals[curLoc]==yVals[(curLoc-1+DATANUM)%DATANUM]
		&& zVals[curLoc]==zVals[(curLoc-1+DATANUM)%DATANUM])
		timeSinceChange++;
	else 
		timeSinceChange=0;
	
	//check for spinning
	//check if the individual values changed from the last check
	if (xVals[curLoc]==xVals[(curLoc-1+DATANUM)%DATANUM])  timeSinceXChange++;
	else  timeSinceXChange=0;
	
	if (yVals[curLoc]==yVals[(curLoc-1+DATANUM)%DATANUM])  timeSinceYChange++;
	else  timeSinceYChange=0;
	
	if (zVals[curLoc]==zVals[(curLoc-1+DATANUM)%DATANUM])  timeSinceZChange++;
	else  timeSinceZChange=0;
	
	//make sure at least two axes have not changed in a while
	int minTime=5;
	if ( ((timeSinceXChange>minTime && timeSinceYChange>minTime) ||
		  (timeSinceYChange>minTime && timeSinceZChange>minTime)  ||
		  (timeSinceXChange>minTime && timeSinceZChange>minTime)) && 
		  !(timeSinceXChange>minTime && timeSinceYChange>minTime && timeSinceZChange>minTime) &&
		  speeds[(curLoc-minTime-3+DATANUM)%DATANUM]>5){
		cout<<"SPINNNNNNN "<<ballID<<endl;
		spinTimer=0;	//reset the spin timer
	}
	
	//set the speed as the largest distance between readings
	speed=max(abs(xVals[curLoc]-xVals[(curLoc-1+DATANUM)%DATANUM]),
			  abs(yVals[curLoc]-yVals[(curLoc-1+DATANUM)%DATANUM]));
	speed=max(speed,abs(zVals[curLoc]-zVals[(curLoc-1+DATANUM)%DATANUM]));
	
	speeds[curLoc]=speed;
	
	//if the speed is aove a certain threshold, reset the move timer
	//and check to see if this is the start of a movement, turning on recording if it is
	if (speed>20){
		stillTimer=0;
		
		//if it was fast enough to absolutely be deliberate, start recording
		if (speed>50 && !singing)
			startRecording();
	}
	
	//check if any of the reading are the highest or lowest
	if (xVals[curLoc]>maxVal) maxVal=xVals[curLoc];
	if (yVals[curLoc]>maxVal) maxVal=yVals[curLoc];
	if (zVals[curLoc]>maxVal) maxVal=zVals[curLoc];
	
	if (xVals[curLoc]<minVal) minVal=xVals[curLoc];
	if (yVals[curLoc]<minVal) minVal=yVals[curLoc];
	if (zVals[curLoc]<minVal) minVal=zVals[curLoc];
	
	//set the soudns with the new values
	setSound();
	
	//if it hasn't moved in x checks, say that it stopped, and end the sound if it was being recorded
	if (stillTimer>4){
		endSound();
	}
	
}

//update for gyro ball
void SingingBowl::update(int _val0, int _val1){
	//advance the possition of the data
	if(++curLoc==DATANUM)
		curLoc=0;
	
	gyro=true;
	//advance the muteTimer
	stillTimer++;
	
	//set the new values
	if (_val0>50 && _val0<1000)
		val0=_val0;
	if (_val1>50 && _val1<1000)
		val1=_val1;
	
	//store the data in the arrays
	xVals[curLoc]=val0;
	yVals[curLoc]=val1;
	
	//see if the values changed at all
	if (xVals[curLoc]==xVals[(curLoc-1+DATANUM)%DATANUM]
		&& yVals[curLoc]==yVals[(curLoc-1+DATANUM)%DATANUM])
		timeSinceChange++;
	else 
		timeSinceChange=0;
	
	//set the speed
	speeds[curLoc]=max(abs(val0-restVal0),abs(val1-restVal1));
	//smooth out the last few readings to get the speed
	int smoothNum=3;	//how many redings to use
	float total=0;
	for (int i=0; i<smoothNum; i++)
		total+=speeds[(curLoc-i+DATANUM)%DATANUM];
	speed=total/smoothNum;
	
	//if the speed has been the same for a number of checks, assume this is the new resting speed
	int numCheck=3;	//how far back to check for identical speeds
	bool reset=true;	//assume we should reset the rest val
	for (int i=0; i<numCheck; i++){
		//check if this value is different
		if (speeds[(curLoc-i+DATANUM)%DATANUM]!=speed)
			reset=false;	//if it was diffeent, don't reset rest values
	}
	if (reset) setRestVal();
	
	//if the speed is aove a certain threshold, reset the move timer
	//and check to see if this is the start of a movement, turning on recording if it is
	if (speed>20){
		stillTimer=0;
		
		//if it was fast enough to absolutely be deliberate, start recording
		if (speed>50 && !singing)
			startRecording();
	}
	
	//set the soudns with the new values
	setSound();

	//if it hasn't moved in x checks, say that it stopped, and end the sound if it was being recorded
	if (stillTimer>4){
		endSound();
	}
}

void SingingBowl::draw(){
	for (int i=0; i<DATANUM-1; i++){
		ofSetColor(col1);
		ofLine(i*4, xVals[i], i*4+4, xVals[i+1]);
		
		ofSetColor(col2);
		ofLine(i*4, yVals[i], i*4+4, yVals[i+1]);
		
		if (!gyro){	//only show the third line for accelerometer balls
			ofSetColor(col3);
			ofLine(i*4, zVals[i], i*4+4, zVals[i+1]);
		}
		
		ofSetColor(col1);
		ofLine(i*4, ofGetHeight()-speeds[i], i*4+4, ofGetHeight()-speeds[i+1]);
	}
	
	//text read out
	int textX=30 + ballID*150;;
	int textY=30;
	int spacing=20;
	int s=0;
	ofSetColor(col1);
	ofDrawBitmapString("Singing Bowl", textX, textY+spacing*s++);
	ofSetColor(0,0, 0);
	ofDrawBitmapString("id    : "+ofToString(ballID), textX, textY+spacing*s++);
	if (gyro) ofDrawBitmapString("gyro", textX, textY+spacing*s++);
	else  ofDrawBitmapString("accel", textX, textY+spacing*s++);
	ofDrawBitmapString("val0  : "+ofToString(val0), textX, textY+spacing*s++);
	ofDrawBitmapString("val1  : "+ofToString(val1), textX, textY+spacing*s++);
	ofDrawBitmapString("val2  : "+ofToString(val2), textX, textY+spacing*s++);
	ofDrawBitmapString("freq  : "+ofToString(freq), textX, textY+spacing*s++);
	ofDrawBitmapString("speed : "+ofToString(speed), textX, textY+spacing*s++);
	ofDrawBitmapString("count : "+ofToString(count), textX, textY+spacing*s++);
	ofDrawBitmapString("length: "+ofToString(playbackLength), textX, textY+spacing*s++);
	ofDrawBitmapString("still : "+ofToString(stillTimer), textX, textY+spacing*s++);
	ofDrawBitmapString("amp0  : "+ofToString(amp), textX, textY+spacing*s++);
	ofDrawBitmapString("noChng: "+ofToString(timeSinceChange), textX, textY+spacing*s++);
	ofDrawBitmapString("mute  : "+ofToString(mute), textX, textY+spacing*s++);
	ofDrawBitmapString("sing  : "+ofToString(singing), textX, textY+spacing*s++);
}

void SingingBowl::setAllData(){
	for (int i=0; i<DATANUM; i++){
		xVals[i]=xVals[(curLoc+DATANUM)%DATANUM];
		yVals[i]=yVals[(curLoc+DATANUM)%DATANUM];
		speeds[i]=speeds[(curLoc+DATANUM)%DATANUM];
	}
}

void SingingBowl::setRestVal(){
	restVal0=xVals[(curLoc+DATANUM)%DATANUM];
	restVal1=yVals[(curLoc+DATANUM)%DATANUM];
}


void SingingBowl::setSound(){
	
	count+=10;

	//are we getting new info right now?
	amp=(int) count/2.5;
	if (count<11)
		amp=0;
	detune=count;
	if(mute)
		amp=0;
}

void SingingBowl::startRecording(){
	if (!singing){
		singing=true;
		count=0;
	}
}

void SingingBowl::endSound(){
	//cout<<"enterring"<<count<<endl;
	if (count>minCount && singing){
		end=true;
	}
	singing=false;
	count=0;
}

//clears the current sounds
void SingingBowl::clearSound(){
	count=0;
	playbackLength=1;
};
