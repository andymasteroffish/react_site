ASCII video Filter
by Andy Wallace

This code is based on the ASCII video program created by Ben Fry and packaged with Processing

In order to run, the font UniversLTStd-Light-48.vlw must be in the same folder as the applet.