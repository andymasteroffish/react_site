import processing.core.*; 
import processing.xml.*; 

import processing.video.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class ASCIIvideo extends PApplet {

/*
 * ASCII video converter
 * by Andy Wallace
 * 2011
 *
 * Based on code by Ben Fry found in the example files bundled with Processing under library/Video (Capture).
 *
 * Pixels are evaluated in square groups of four, which are compared to a list of letters.
 * Each character was processed by a seperate application for it's weight in the four quadrants.
 * The program selects ASCII character that best fits each pixel group.
 */



Capture video;  //gets the image from the camera

//size of video
int vidW=PApplet.parseInt(160*1.3f);
int vidH=PApplet.parseInt(120*1.3f);

//letters
char[] letters;
float[][] letterWeight;

//font info
PFont font;
float fontSize = 12;

//sizing
float scaleW;
float scaleH;

public void setup(){
  size(640*2,480*2);
  scaleW=width/vidW;
  scaleH=height/vidH;
  
  //font size needs to scale with the size of the window and the resolution of the incoming video
  fontSize=12*(width/640)*(160/PApplet.parseFloat(vidW));
  
  //set the font
  font = loadFont("UniversLTStd-Light-48.vlw");
  
  //width, height, and fps set by Capture()
  video= new Capture (this,vidW,vidH,15);
  
  //setting up letters
  setLetters();
  
}

//get the new frame when it is available
public void captureEvent(Capture c){
  c.read();
}

public void draw(){
  background(255);
  fill(0);
  textFont(font, fontSize);
  
  //set(0, 0, video);    //show the video
  
  //checking each group of 4 pixels
  for (int x=0; x<vidW-1; x+=2){
    // Move down for next line
    //translate(0,  1.0 / fontSize);
    
    for (int y=0; y<vidH-1; y+=2){
      int[] vals=new int[4];  //stores the four values
      
      for (int i=0; i<4; i++){
        //figure out which of the four x,y values we're checking
        int checkX=x;
        int checkY=y;
        if (i%2==1)  checkX=x+1;
        if (i>1)     checkY=y+1;
        
        //get the pixel color at this point
        int pixColor=video.pixels[getPixel(checkX,checkY)];
        
        //bitshifting to get the different color values
        int r = (pixColor>>16) & 0xff;  //I think & is the union operator, but I should check.
        int g = (pixColor>>8) & 0xff;
        int b = (pixColor) & 0xff;
        
        //find the strongest value
        vals[i]=max(r,g,b);
      }
      
      //go through all of the letetrs and see which one is the best fit
      int bestFit=0;           //array location of the best Fit
      int bestFitDif=10000;  //difference in pixels from bestFit to the current ixel group
      for (int i=0; i<94; i++){
        //find out how closely this letter[i] fits the current group of 4 pixels 
        int dif=0;
        for (int k=0; k<4; k++)
          dif+=abs(letterWeight[i][k]-vals[k]);
         
        //is this a clsoer fit than the current bestFit?
        if (dif<bestFitDif){
          bestFit=i;
          bestFitDif=dif;
        }
      }
      
      //draw the letter
      text(letters[bestFit],map(x,0,vidW,0,width),map(y,0,vidH,0,height));
    }
  }
 
 
}


public int getPixel(int x, int y){
  return x+y*vidW;
}

public void setLetters(){
  
  //fill letters with 94 chars
  letters=new char[94];
  String lettersString =
  " .`-_':,;^=+/\"|)\\<>)%*&{}][$@?!#1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM";//fill the array based on Ben Fry's string
  for (int i=0; i<94; i++)
    letters[i]=lettersString.charAt(i);
  
  
  letterWeight=new float[94][4];

  //copy pasted from ASCIIvideoCharacterWeights output
  letterWeight[0][0]=255.0f;
  letterWeight[0][1]=249.58127f;
  letterWeight[0][2]=249.58127f;
  letterWeight[0][3]=244.19861f;
  letterWeight[1][0]=255.0f;
  letterWeight[1][1]=249.58127f;
  letterWeight[1][2]=208.46277f;
  letterWeight[1][3]=244.19861f;
  letterWeight[2][0]=203.42131f;
  letterWeight[2][1]=249.58127f;
  letterWeight[2][2]=249.58127f;
  letterWeight[2][3]=244.19861f;
  letterWeight[3][0]=255.0f;
  letterWeight[3][1]=249.58127f;
  letterWeight[3][2]=162.6059f;
  letterWeight[3][3]=244.19861f;
  letterWeight[4][0]=255.0f;
  letterWeight[4][1]=249.58127f;
  letterWeight[4][2]=249.58127f;
  letterWeight[4][3]=244.19861f;
  letterWeight[5][0]=186.5455f;
  letterWeight[5][1]=249.58127f;
  letterWeight[5][2]=249.58127f;
  letterWeight[5][3]=244.19861f;
  letterWeight[6][0]=213.93822f;
  letterWeight[6][1]=249.58127f;
  letterWeight[6][2]=209.49612f;
  letterWeight[6][3]=244.19861f;
  letterWeight[7][0]=255.0f;
  letterWeight[7][1]=249.58127f;
  letterWeight[7][2]=210.03853f;
  letterWeight[7][3]=244.19861f;
  letterWeight[8][0]=215.12138f;
  letterWeight[8][1]=249.58127f;
  letterWeight[8][2]=211.42337f;
  letterWeight[8][3]=244.19861f;
  letterWeight[9][0]=166.54803f;
  letterWeight[9][1]=136.90443f;
  letterWeight[9][2]=208.01595f;
  letterWeight[9][3]=202.96582f;
  letterWeight[10][0]=238.44655f;
  letterWeight[10][1]=229.61192f;
  letterWeight[10][2]=113.49992f;
  letterWeight[10][3]=80.211525f;
  letterWeight[11][0]=249.11235f;
  letterWeight[11][1]=210.84901f;
  letterWeight[11][2]=158.5454f;
  letterWeight[11][3]=63.920185f;
  letterWeight[12][0]=124.19985f;
  letterWeight[12][1]=249.49216f;
  letterWeight[12][2]=113.61626f;
  letterWeight[12][3]=244.19861f;
  letterWeight[13][0]=118.30865f;
  letterWeight[13][1]=249.58127f;
  letterWeight[13][2]=249.58127f;
  letterWeight[13][3]=244.19861f;
  letterWeight[14][0]=125.50251f;
  letterWeight[14][1]=249.58127f;
  letterWeight[14][2]=120.94708f;
  letterWeight[14][3]=244.19861f;
  letterWeight[15][0]=133.23085f;
  letterWeight[15][1]=249.58127f;
  letterWeight[15][2]=112.16954f;
  letterWeight[15][3]=244.19861f;
  letterWeight[16][0]=122.55756f;
  letterWeight[16][1]=249.58127f;
  letterWeight[16][2]=116.336945f;
  letterWeight[16][3]=242.07928f;
  letterWeight[17][0]=253.49832f;
  letterWeight[17][1]=167.79312f;
  letterWeight[17][2]=105.509476f;
  letterWeight[17][3]=129.18309f;
  letterWeight[18][0]=175.92451f;
  letterWeight[18][1]=240.0489f;
  letterWeight[18][2]=163.01141f;
  letterWeight[18][3]=75.02624f;
  letterWeight[19][0]=133.23085f;
  letterWeight[19][1]=249.58127f;
  letterWeight[19][2]=112.16954f;
  letterWeight[19][3]=244.19861f;
  letterWeight[20][0]=123.85321f;
  letterWeight[20][1]=31.175058f;
  letterWeight[20][2]=220.74445f;
  letterWeight[20][3]=16.44722f;
  letterWeight[21][0]=101.11018f;
  letterWeight[21][1]=142.32828f;
  letterWeight[21][2]=249.58127f;
  letterWeight[21][3]=244.19861f;
  letterWeight[22][0]=69.440186f;
  letterWeight[22][1]=65.16126f;
  letterWeight[22][2]=51.648434f;
  letterWeight[22][3]=-89.24801f;
  letterWeight[23][0]=108.1928f;
  letterWeight[23][1]=249.58127f;
  letterWeight[23][2]=96.87294f;
  letterWeight[23][3]=244.19861f;
  letterWeight[24][0]=107.42569f;
  letterWeight[24][1]=249.58127f;
  letterWeight[24][2]=96.64687f;
  letterWeight[24][3]=244.19861f;
  letterWeight[25][0]=100.72925f;
  letterWeight[25][1]=249.58127f;
  letterWeight[25][2]=110.477356f;
  letterWeight[25][3]=244.19861f;
  letterWeight[26][0]=101.407845f;
  letterWeight[26][1]=249.58127f;
  letterWeight[26][2]=110.477356f;
  letterWeight[26][3]=244.19861f;
  letterWeight[27][0]=-20.04906f;
  letterWeight[27][1]=160.36298f;
  letterWeight[27][2]=29.859222f;
  letterWeight[27][3]=45.70874f;
  letterWeight[28][0]=59.41646f;
  letterWeight[28][1]=-48.200092f;
  letterWeight[28][2]=13.483257f;
  letterWeight[28][3]=-74.375565f;
  letterWeight[29][0]=168.04073f;
  letterWeight[29][1]=124.1465f;
  letterWeight[29][2]=134.0746f;
  letterWeight[29][3]=243.77672f;
  letterWeight[30][0]=105.48186f;
  letterWeight[30][1]=249.58127f;
  letterWeight[30][2]=143.18857f;
  letterWeight[30][3]=244.19861f;
  letterWeight[31][0]=77.83748f;
  letterWeight[31][1]=84.34351f;
  letterWeight[31][2]=50.478363f;
  letterWeight[31][3]=77.15432f;
  letterWeight[32][0]=132.43782f;
  letterWeight[32][1]=196.04541f;
  letterWeight[32][2]=178.34781f;
  letterWeight[32][3]=184.38245f;
  letterWeight[33][0]=139.8695f;
  letterWeight[33][1]=95.28547f;
  letterWeight[33][2]=50.299473f;
  letterWeight[33][3]=143.44046f;
  letterWeight[34][0]=125.750854f;
  letterWeight[34][1]=93.29142f;
  letterWeight[34][2]=114.69392f;
  letterWeight[34][3]=73.929565f;
  letterWeight[35][0]=167.92502f;
  letterWeight[35][1]=108.68667f;
  letterWeight[35][2]=108.05044f;
  letterWeight[35][3]=60.666046f;
  letterWeight[36][0]=34.39028f;
  letterWeight[36][1]=145.13747f;
  letterWeight[36][2]=109.108986f;
  letterWeight[36][3]=78.341415f;
  letterWeight[37][0]=41.485504f;
  letterWeight[37][1]=113.163055f;
  letterWeight[37][2]=43.320496f;
  letterWeight[37][3]=74.7276f;
  letterWeight[38][0]=166.42465f;
  letterWeight[38][1]=79.4804f;
  letterWeight[38][2]=130.43973f;
  letterWeight[38][3]=211.43874f;
  letterWeight[39][0]=70.2141f;
  letterWeight[39][1]=94.004745f;
  letterWeight[39][2]=39.898712f;
  letterWeight[39][3]=63.229923f;
  letterWeight[40][0]=80.73199f;
  letterWeight[40][1]=84.864174f;
  letterWeight[40][2]=71.2102f;
  letterWeight[40][3]=48.05841f;
  letterWeight[41][0]=86.43521f;
  letterWeight[41][1]=101.53566f;
  letterWeight[41][2]=69.75084f;
  letterWeight[41][3]=82.25113f;
  letterWeight[42][0]=163.17708f;
  letterWeight[42][1]=158.38931f;
  letterWeight[42][2]=78.41349f;
  letterWeight[42][3]=60.922028f;
  letterWeight[43][0]=203.70633f;
  letterWeight[43][1]=166.75883f;
  letterWeight[43][2]=67.0997f;
  letterWeight[43][3]=9.981803f;
  letterWeight[44][0]=168.99625f;
  letterWeight[44][1]=182.50491f;
  letterWeight[44][2]=20.847347f;
  letterWeight[44][3]=84.4118f;
  letterWeight[45][0]=148.0424f;
  letterWeight[45][1]=247.18028f;
  letterWeight[45][2]=121.825134f;
  letterWeight[45][3]=244.19861f;
  letterWeight[46][0]=98.29884f;
  letterWeight[46][1]=249.18459f;
  letterWeight[46][2]=94.25668f;
  letterWeight[46][3]=243.3778f;
  letterWeight[47][0]=198.1908f;
  letterWeight[47][1]=198.44484f;
  letterWeight[47][2]=64.70368f;
  letterWeight[47][3]=161.82243f;
  letterWeight[48][0]=207.7746f;
  letterWeight[48][1]=202.52727f;
  letterWeight[48][2]=88.12988f;
  letterWeight[48][3]=78.01354f;
  letterWeight[49][0]=178.7353f;
  letterWeight[49][1]=249.58127f;
  letterWeight[49][2]=123.537025f;
  letterWeight[49][3]=244.19861f;
  letterWeight[50][0]=166.81546f;
  letterWeight[50][1]=180.29166f;
  letterWeight[50][2]=78.86115f;
  letterWeight[50][3]=89.54299f;
  letterWeight[51][0]=146.91512f;
  letterWeight[51][1]=176.39838f;
  letterWeight[51][2]=51.281075f;
  letterWeight[51][3]=89.346596f;
  letterWeight[52][0]=166.50917f;
  letterWeight[52][1]=197.0498f;
  letterWeight[52][2]=43.213005f;
  letterWeight[52][3]=74.78724f;
  letterWeight[53][0]=160.09566f;
  letterWeight[53][1]=198.12125f;
  letterWeight[53][2]=64.27844f;
  letterWeight[53][3]=125.960335f;
  letterWeight[54][0]=164.6957f;
  letterWeight[54][1]=83.1623f;
  letterWeight[54][2]=80.02553f;
  letterWeight[54][3]=59.10829f;
  letterWeight[55][0]=34.039413f;
  letterWeight[55][1]=248.56183f;
  letterWeight[55][2]=123.06131f;
  letterWeight[55][3]=244.19861f;
  letterWeight[56][0]=161.40959f;
  letterWeight[56][1]=156.68588f;
  letterWeight[56][2]=73.30992f;
  letterWeight[56][3]=61.278347f;
  letterWeight[57][0]=77.16993f;
  letterWeight[57][1]=181.7229f;
  letterWeight[57][2]=121.13886f;
  letterWeight[57][3]=117.8393f;
  letterWeight[58][0]=178.7353f;
  letterWeight[58][1]=249.58127f;
  letterWeight[58][2]=120.95385f;
  letterWeight[58][3]=244.19861f;
  letterWeight[59][0]=117.483475f;
  letterWeight[59][1]=204.66132f;
  letterWeight[59][2]=26.112734f;
  letterWeight[59][3]=179.82065f;
  letterWeight[60][0]=132.21268f;
  letterWeight[60][1]=249.58127f;
  letterWeight[60][2]=123.537025f;
  letterWeight[60][3]=244.19861f;
  letterWeight[61][0]=165.49602f;
  letterWeight[61][1]=191.31717f;
  letterWeight[61][2]=42.091576f;
  letterWeight[61][3]=209.23416f;
  letterWeight[62][0]=193.31645f;
  letterWeight[62][1]=200.08775f;
  letterWeight[62][2]=66.450836f;
  letterWeight[62][3]=149.9339f;
  letterWeight[63][0]=168.94177f;
  letterWeight[63][1]=189.25304f;
  letterWeight[63][2]=79.06995f;
  letterWeight[63][3]=169.64883f;
  letterWeight[64][0]=202.85974f;
  letterWeight[64][1]=197.54834f;
  letterWeight[64][2]=73.59611f;
  letterWeight[64][3]=156.7032f;
  letterWeight[65][0]=72.1633f;
  letterWeight[65][1]=176.70917f;
  letterWeight[65][2]=53.521263f;
  letterWeight[65][3]=89.636475f;
  letterWeight[66][0]=151.37764f;
  letterWeight[66][1]=181.24509f;
  letterWeight[66][2]=121.17743f;
  letterWeight[66][3]=117.85409f;
  letterWeight[67][0]=151.17137f;
  letterWeight[67][1]=111.88949f;
  letterWeight[67][2]=121.04027f;
  letterWeight[67][3]=115.51925f;
  letterWeight[68][0]=91.37161f;
  letterWeight[68][1]=49.368702f;
  letterWeight[68][2]=82.14286f;
  letterWeight[68][3]=13.770704f;
  letterWeight[69][0]=115.499695f;
  letterWeight[69][1]=6.190956f;
  letterWeight[69][2]=65.32332f;
  letterWeight[69][3]=107.40192f;
  letterWeight[70][0]=44.575974f;
  letterWeight[70][1]=128.14104f;
  letterWeight[70][2]=47.426025f;
  letterWeight[70][3]=134.92883f;
  letterWeight[71][0]=44.15891f;
  letterWeight[71][1]=34.20045f;
  letterWeight[71][2]=96.60164f;
  letterWeight[71][3]=81.2794f;
  letterWeight[72][0]=56.38275f;
  letterWeight[72][1]=159.58836f;
  letterWeight[72][2]=129.81189f;
  letterWeight[72][3]=233.7813f;
  letterWeight[73][0]=92.607635f;
  letterWeight[73][1]=111.64368f;
  letterWeight[73][2]=177.0366f;
  letterWeight[73][3]=175.36906f;
  letterWeight[74][0]=122.223526f;
  letterWeight[74][1]=116.95999f;
  letterWeight[74][2]=89.23117f;
  letterWeight[74][3]=49.54015f;
  letterWeight[75][0]=116.66053f;
  letterWeight[75][1]=249.58127f;
  letterWeight[75][2]=108.72777f;
  letterWeight[75][3]=244.19861f;
  letterWeight[76][0]=91.394516f;
  letterWeight[76][1]=48.46434f;
  letterWeight[76][2]=82.20376f;
  letterWeight[76][3]=45.610443f;
  letterWeight[77][0]=67.621735f;
  letterWeight[77][1]=50.63094f;
  letterWeight[77][2]=72.14486f;
  letterWeight[77][3]=205.64458f;
  letterWeight[78][0]=149.0646f;
  letterWeight[78][1]=107.87112f;
  letterWeight[78][2]=64.25928f;
  letterWeight[78][3]=32.3907f;
  letterWeight[79][0]=50.076763f;
  letterWeight[79][1]=145.4989f;
  letterWeight[79][2]=129.94374f;
  letterWeight[79][3]=29.123972f;
  letterWeight[80][0]=70.33268f;
  letterWeight[80][1]=53.11801f;
  letterWeight[80][2]=61.470024f;
  letterWeight[80][3]=52.087048f;
  letterWeight[81][0]=37.369663f;
  letterWeight[81][1]=139.32748f;
  letterWeight[81][2]=98.35322f;
  letterWeight[81][3]=225.57161f;
  letterWeight[82][0]=95.70432f;
  letterWeight[82][1]=110.22074f;
  letterWeight[82][2]=79.28814f;
  letterWeight[82][3]=-24.099098f;
  letterWeight[83][0]=90.435776f;
  letterWeight[83][1]=60.872467f;
  letterWeight[83][2]=97.004555f;
  letterWeight[83][3]=79.25813f;
  letterWeight[84][0]=255.0f;
  letterWeight[84][1]=116.80473f;
  letterWeight[84][2]=123.19972f;
  letterWeight[84][3]=119.69885f;
  letterWeight[85][0]=62.086796f;
  letterWeight[85][1]=145.84184f;
  letterWeight[85][2]=69.63172f;
  letterWeight[85][3]=103.10018f;
  letterWeight[86][0]=122.223526f;
  letterWeight[86][1]=249.58127f;
  letterWeight[86][2]=64.25684f;
  letterWeight[86][3]=168.25877f;
  letterWeight[87][0]=145.1253f;
  letterWeight[87][1]=65.80882f;
  letterWeight[87][2]=24.619518f;
  letterWeight[87][3]=170.87108f;
  letterWeight[88][0]=97.931046f;
  letterWeight[88][1]=111.31075f;
  letterWeight[88][2]=101.926605f;
  letterWeight[88][3]=82.31353f;
  letterWeight[89][0]=90.96461f;
  letterWeight[89][1]=122.868065f;
  letterWeight[89][2]=80.93671f;
  letterWeight[89][3]=123.81722f;
  letterWeight[90][0]=115.276306f;
  letterWeight[90][1]=122.30198f;
  letterWeight[90][2]=121.229866f;
  letterWeight[90][3]=125.1819f;
  letterWeight[91][0]=42.918507f;
  letterWeight[91][1]=44.025204f;
  letterWeight[91][2]=47.12739f;
  letterWeight[91][3]=24.352352f;
  letterWeight[92][0]=28.573591f;
  letterWeight[92][1]=87.801476f;
  letterWeight[92][2]=113.27808f;
  letterWeight[92][3]=-24.99451f;
  letterWeight[93][0]=11.423707f;
  letterWeight[93][1]=187.36931f;
  letterWeight[93][2]=110.22828f;
  letterWeight[93][3]=-20.92726f;



}
  
  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "ASCIIvideo" });
  }
}
